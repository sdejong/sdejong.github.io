import pandas
from keras.models import Sequential
from keras.layers import Dense
from keras.wrappers.scikit_learn import KerasClassifier
from keras.utils import np_utils
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import KFold
from sklearn.preprocessing import LabelEncoder
from sklearn.pipeline import Pipeline
import numpy as np
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split 
from sklearn.metrics import confusion_matrix 
from sklearn.tree import DecisionTreeClassifier 
from sklearn.metrics import accuracy_score
from sklearn.naive_bayes import GaussianNB 
from sklearn.svm import SVC 

# Read the genre data from combine_data.py and extract the columns that are needed
dataframe = pandas.read_csv("genre_data", header=None)
dataframe = dataframe.dropna()
dataset = dataframe.values
X = dataset[:, [3]].astype(float)
Y = dataset[:,1]
print(X)
print(X.shape)
print(Y.shape)

X_train, X_test, y_train, y_test = train_test_split(X, Y, random_state = 0) 

# Use the K-nearest-Neighours classifier and return the 
# resulting accuracy and confusion matrix
knn = KNeighborsClassifier(n_neighbors = 7).fit(X_train, y_train) 
accuracy = knn.score(X_test, y_test) 
print(accuracy)
knn_predictions = knn.predict(X_test)	
cm = confusion_matrix(y_test, knn_predictions) 
print(cm)


# Use the Decision Tree classifier and return the 
# resulting accuracy and confusion matrix
dtree_model = DecisionTreeClassifier(max_depth = 2).fit(X_train, y_train) 
dtree_predictions = dtree_model.predict(X_test) 
accuracy = accuracy_score(y_test, dtree_predictions)
print(accuracy)
  
cm = confusion_matrix(y_test, dtree_predictions) 
print(cm)



# Use the Gaussian Naive Bayes classifier and return the 
# resulting accuracy and confusion matrix
gnb = GaussianNB().fit(X_train, y_train) 
gnb_predictions = gnb.predict(X_test) 
  
accuracy = gnb.score(X_test, y_test) 
print(accuracy) 
  
cm = confusion_matrix(y_test, gnb_predictions) 
print(cm)


# Use the Support Vector Machine classifier and return the 
# resulting accuracy and confusion matrix
svm_model_linear = SVC(kernel = 'linear', C = 1).fit(X_train, y_train) 
svm_predictions = svm_model_linear.predict(X_test) 
  
accuracy = svm_model_linear.score(X_test, y_test) 
print(accuracy)
  
cm = confusion_matrix(y_test, svm_predictions) 
print(cm)

#Convert the potential genres outcomes using one-hot encoding
encoder = LabelEncoder()
encoder.fit(Y)
encoded_Y = encoder.transform(Y)
dummy_y = np_utils.to_categorical(encoded_Y)

X_train, X_test, y_train, y_test = train_test_split(X, dummy_y, random_state = 0) 
def baseline_model():
	model = Sequential()
	model.add(Dense(512, input_dim=1, activation='relu'))
	model.add(Dense(512, activation='relu'))
	model.add(Dense(3, activation='softmax'))
	model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
	return model
# Build a simple feed-forward neural network and test its performance on the genre and dr data
model = baseline_model()
model.summary()
model.fit(X_train, y_train, batch_size=100, nb_epoch=25, validation_data=(X_test, y_test))
