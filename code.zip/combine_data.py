import csv, pandas as pd

# Open the dr data obtained in scrape_dr.py and the genre data obtained in get_genre.py
data = pd.read_csv("dr_data.csv") 
data = data[data['Year'] >= 1985.0]
data = data[data['source'] != "Vinyl"]


with open('genres.csv', mode='r') as infile:
    reader = csv.reader(infile)
    genres = {rows[0]:rows[1] for rows in reader}

temp_df = [[]]
# Iterate over the albums and combine all subgenres into logical categories.
for index, row in data.iterrows():
	try:
		if "pop" in genres[row['Artist']]:
			temp_df.append(["pop", row['Album'], row['avg DR'], row['Year']])	
		if "rock" in genres[row['Artist']]:
			temp_df.append(["rock", row['Album'], row['avg DR'], row['Year']])	
		if "metal" in genres[row['Artist']]:
			temp_df.append(["metal", row['Album'], row['avg DR'], row['Year']])		
		if "jazz" in genres[row['Artist']]:
			temp_df.append(["jazz", row['Album'], row['avg DR'], row['Year']])	
		if "classical" in genres[row['Artist']]:
			temp_df.append(["classical", row['Album'], row['avg DR'], row['Year']])	
		if "hiphop" in genres[row['Artist']] or "rap" in genres[row['Artist']]:
			temp_df.append(["rap", row['Album'], row['avg DR'], row['Year']])	
		if "blues" in genres[row['Artist']]:
			temp_df.append(["blues", row['Album'], row['avg DR'], row['Year']])		
	except:
		print("Artist not in database")
# Save the combination of album, dr and genre data
data  = pd.DataFrame(temp_df, columns = ["Genre", "Album", "DR", "Year"])
data.to_csv('genre_data.csv', encoding="utf-8")
