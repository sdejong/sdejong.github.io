import numpy as np
from sklearn.linear_model import LinearRegression
import pandas as pd
import matplotlib.pyplot as plt 
import discogs_client
import pylast
import os, time
import requests


# Read the dr data obtained in scrape_dr and find all the artists.
data = pd.read_csv("dr_data.csv") 
data = data[data['Year'] >= 1985.0]
artists = data['Artist'].unique()
# A Last.fm API key is needed to use this script.
API_KEY = 
URL = "http://ws.audioscrobbler.com/2.0/"
# Find an artist and return its most popular genre.
def get_genre(artist, PARAMS):
	r = requests.get(url = URL, params = PARAMS).json()

	try:
		genre = list(list(r.values())[0].values())[0][0]['name']
		return genre
	except: 
		return "Not found"	

genres = np.empty([len(artists), 2], dtype="U200")
for i in range(0, len(artists)):
	artist = artists[i]
	PARAMS = {'method': 'artist.gettoptags', 'artist' : artist, 'api_key':API_KEY, 'format':'json'}
	genre = get_genre(artist, PARAMS)
	if(genre != "Not found"):
		genres[i] = [artist, genre]	
		np.savetxt('genres.txt', genres, fmt='%s', delimiter=',')

