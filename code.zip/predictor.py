import numpy as np
from sklearn.linear_model import LinearRegression
import pandas as pd
import matplotlib.pyplot as plt 
from sklearn.model_selection import train_test_split 
from sklearn.metrics import accuracy_score
from sklearn import metrics
from sklearn.preprocessing import LabelEncoder
from sklearn.pipeline import Pipeline
from keras.utils import np_utils
from keras.models import Sequential
from keras.layers import Dense
from keras.wrappers.scikit_learn import KerasClassifier

# Read the DR data that was scraped using scrape_dr.py and 
# prepare the means as training data and the individual values
# as test values.
data = pd.read_csv("dr_data.csv") 
data = data[data['source'] != 'Vinyl']
data = data[['Year','avg DR']]
data = data[data['Year'] >= 1985.0]
data_mean = data.groupby(['Year'])['avg DR'].mean()
data_mean = pd.DataFrame(data_mean, columns = ['avg DR'])
dr_train = np.array(data_mean.iloc[:,0]).reshape((-1, 1))
year_train = np.array(data_mean.index.values).reshape((-1, 1))

dr_test = np.array(data['avg DR']).reshape(-1,1)
year_test = np.array(data['Year'])

# Perform the linear regression and print the outcome
model = LinearRegression().fit(dr_train, year_train)
r_sq = model.score(dr_train, year_train)

print('coefficient of determination:', r_sq)
print('intercept:', model.intercept_)
print('slope:', model.coef_)

y_pred = model.predict(dr_test)
df = pd.DataFrame({'Actual': year_test.flatten(), 'Predicted': y_pred.flatten()})
print(df)

# Plot the means per year and the regression line
plt.scatter(year_train, dr_train)
axes = plt.gca()
axes.set_xlim([1980,2020])
axes.set_ylim([0,20])
axes.set_title("Dynamic range of albums from 1985 to 2019")
axes.set_xlabel("Year")
axes.set_ylabel("DR value")
y_pred = model.predict(year_train)
plt.plot(year_train, y_pred, color='red')
plt.show()

print('Mean Absolute Error:', metrics.mean_absolute_error(year_train, y_pred))  
print('Mean Squared Error:', metrics.mean_squared_error(year_train, y_pred))  
print('Root Mean Squared Error:', np.sqrt(metrics.mean_squared_error(year_train, y_pred)))

# Encode the potential output years with one-hot encoding
encoder = LabelEncoder()
encoder.fit(year_test)
encoded_Y = encoder.transform(year_test)
dummy_y = np_utils.to_categorical(encoded_Y)
X_train, X_test, y_train, y_test = train_test_split(dr_test, dummy_y, random_state = 0) 


def baseline_model():
	model = Sequential()
	model.add(Dense(512, input_dim=1, activation='relu'))
	model.add(Dense(512, activation='relu'))
	model.add(Dense(35, activation='softmax'))
	model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
	return model

# Build a simple feed-forward neural network and test its performance on the year and dr data
model = baseline_model()
model.summary()
model.fit(X_train, y_train, batch_size=100, nb_epoch=25, validation_data=(X_test, y_test))

