from selenium import webdriver
from BeautifulSoup import BeautifulSoup
import pandas as pd

driver = webdriver.Chrome()
results = [[]]
# nr_pages should contain the amount of pages of http://dr.loudness-war.info/album/list/
# While scraping the data this value was 1391
nr_pages = 1391 
def add_page(url):
	driver.get(url)
	content = driver.page_source
	
	# Use the BeautifulSoup package to find the right column and save its values in results
	bs=BeautifulSoup(content)
	div = bs.find('div', {'class': 'table-responsive-sm'})
	if div is not None:
		rows  = div.findAll('tr')
		#print(rows)
		for row in rows:
			tds=row.findAll('td')
			result = []
			for td in tds:
				if td:
					data = td.text.strip()
		    		if data:
		       			result.append(data)
			results.append(result)

	
for i in range(1,nr_pages+1):
	add_page("http://dr.loudness-war.info/album/list/" + str(i))
# Create a dataframe from results and save it to disc.
df = pd.DataFrame(results, columns=["Artist", "Album", "Year", "avg DR", "min DR", "max DR", "codec", "source"])
print(df)		
df.to_csv('dr_data.csv', encoding="utf-8")
